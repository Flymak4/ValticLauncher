package dev.valtic.cosmetics.data;
import net.minecraft.util.Identifier;
public record CosmeticEntry(
        String id,
        String displayName,
        CosmeticType type,
        Identifier texture,
        String description
) {
    public static CosmeticEntry of(String id, String name, CosmeticType type, String texturePath, String desc) {
        return new CosmeticEntry(id, name, type,
                Identifier.of("valtic_cosmetics", texturePath), desc);
    }
}
