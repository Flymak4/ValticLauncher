package dev.valtic.cosmetics.client.model;
import net.minecraft.client.model.*;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
public class HatModel extends EntityModel<PlayerEntityRenderState> {
    private final ModelPart headMount;
    private final ModelPart brim;
    private final ModelPart band;
    private final ModelPart crown;
    private final ModelPart tip;
    public HatModel(ModelPart root) {
        super(root);
        headMount = root.getChild("headMount");
        brim      = headMount.getChild("brim");
        band      = headMount.getChild("band");
        crown     = headMount.getChild("crown");
        tip       = crown.getChild("tip");
    }
    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        ModelPartData mount = root.addChild("headMount",
                ModelPartBuilder.create(),
                ModelTransform.pivot(0f, -8f, 0f));
        mount.addChild("brim",
                ModelPartBuilder.create().uv(0, 0)
                        .cuboid(-6f, -2f, -6f, 12, 2, 12),
                ModelTransform.pivot(0f, 0f, 0f));
        mount.addChild("band",
                ModelPartBuilder.create().uv(0, 14)
                        .cuboid(-5f, -6f, -5f, 10, 4, 10),
                ModelTransform.pivot(0f, 0f, 0f));
        ModelPartData crownPart = mount.addChild("crown",
                ModelPartBuilder.create().uv(0, 28)
                        .cuboid(-4f, -13f, -4f, 8, 7, 8),
                ModelTransform.pivot(0f, 0f, 0f));
        crownPart.addChild("tip",
                ModelPartBuilder.create().uv(40, 0)
                        .cuboid(-2f, -8f, -2f, 4, 8, 4),
                ModelTransform.pivot(0f, -13f, 0f));
        return TexturedModelData.of(data, 64, 64);
    }
    @Override
    public void setAngles(PlayerEntityRenderState state) {
    }
}
