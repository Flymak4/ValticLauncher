package dev.valtic.cosmetics.client.render;
import dev.valtic.cosmetics.client.model.*;
import dev.valtic.cosmetics.data.CosmeticEntry;
import dev.valtic.cosmetics.data.CosmeticType;
import dev.valtic.cosmetics.data.PlayerCosmeticState;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererProvider;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.RotationAxis;
public class CosmeticRenderer<T extends PlayerEntity, M extends EntityModel<PlayerEntityRenderState>>
        extends FeatureRenderer<PlayerEntityRenderState, M> {
    private final WingsModel    wingsModel;
    private final CapeModel     capeModel;
    private final HatModel      hatModel;
    private final HornsModel    hornsModel;
    public CosmeticRenderer(LivingEntityRenderer<T, M> renderer,
                            EntityRendererProvider.Context context) {
        super(renderer);
        wingsModel = new WingsModel(context.getPart(CosmeticModelLayers.WINGS));
        capeModel  = new CapeModel(context.getPart(CosmeticModelLayers.CAPE));
        hatModel   = new HatModel(context.getPart(CosmeticModelLayers.HAT));
        hornsModel = new HornsModel(context.getPart(CosmeticModelLayers.HORNS));
    }
    @Override
    public void render(MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers,
                       int light,
                       PlayerEntityRenderState state,
                       float limbAngle,
                       float limbDistance) {
        PlayerCosmeticState cosState = PlayerCosmeticState.get();
        CosmeticEntry wings = cosState.getEquippedEntry(CosmeticType.WINGS);
        if (wings != null) {
            renderWings(matrices, vertexConsumers, light, state, wings, limbAngle, limbDistance);
        }
        CosmeticEntry cape = cosState.getEquippedEntry(CosmeticType.CAPE);
        if (cape != null) {
            renderCape(matrices, vertexConsumers, light, state, cape, limbAngle, limbDistance);
        }
        CosmeticEntry hat = cosState.getEquippedEntry(CosmeticType.HAT);
        if (hat != null) {
            renderHat(matrices, vertexConsumers, light, state, hat);
        }
        CosmeticEntry horns = cosState.getEquippedEntry(CosmeticType.HORNS);
        if (horns != null) {
            renderHorns(matrices, vertexConsumers, light, state, horns);
        }
    }
    private void renderWings(MatrixStack matrices,
                              VertexConsumerProvider vcp,
                              int light,
                              PlayerEntityRenderState state,
                              CosmeticEntry entry,
                              float limbAngle,
                              float limbDistance) {
        matrices.push();
        matrices.translate(0.0f, -0.4f, 0.12f);
        float speed    = limbDistance > 0.1f ? 2.5f : 0.6f;
        float flapAmp  = limbDistance > 0.1f ? 0.35f : 0.12f;
        float tick     = (System.currentTimeMillis() % 100000L) / 1000f;
        float flapAngle = (float)(Math.sin(tick * speed) * flapAmp);
        wingsModel.setFlapAngle(flapAngle);
        wingsModel.setMoving(limbDistance > 0.1f);
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(entry.texture()));
        wingsModel.render(matrices, vc, light, OverlayTexture.DEFAULT_UV, 0xFFFFFFFF);
        matrices.pop();
    }
    private void renderCape(MatrixStack matrices,
                             VertexConsumerProvider vcp,
                             int light,
                             PlayerEntityRenderState state,
                             CosmeticEntry entry,
                             float limbAngle,
                             float limbDistance) {
        matrices.push();
        matrices.translate(0.0f, -0.5f, 0.125f);
        float sway = limbDistance > 0.05f
                ? (float)(Math.sin(limbAngle * 0.5f) * 0.1f)
                : 0f;
        capeModel.setSwayAngle(sway);
        capeModel.setMoving(limbDistance > 0.05f);
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(entry.texture()));
        capeModel.render(matrices, vc, light, OverlayTexture.DEFAULT_UV, 0xFFFFFFFF);
        matrices.pop();
    }
    private void renderHat(MatrixStack matrices,
                            VertexConsumerProvider vcp,
                            int light,
                            PlayerEntityRenderState state,
                            CosmeticEntry entry) {
        matrices.push();
        matrices.translate(0.0f, -0.5f, 0.0f);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-state.headYaw));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(state.pitch));
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(entry.texture()));
        hatModel.render(matrices, vc, light, OverlayTexture.DEFAULT_UV, 0xFFFFFFFF);
        matrices.pop();
    }
    private void renderHorns(MatrixStack matrices,
                              VertexConsumerProvider vcp,
                              int light,
                              PlayerEntityRenderState state,
                              CosmeticEntry entry) {
        matrices.push();
        matrices.translate(0.0f, -0.3f, 0.0f);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-state.headYaw));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(state.pitch));
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(entry.texture()));
        hornsModel.render(matrices, vc, light, OverlayTexture.DEFAULT_UV, 0xFFFFFFFF);
        matrices.pop();
    }
}
