# Valtic Cosmetics Preview — Fabric 26.3 (v0.2.0)

Original, **client-only** 3D cosmetic preview with a cosmetics locker on the **Minecraft title screen and pause menu**.
This is a prototype for review, not Lunar Client's models or textures and not the paid release.

## What's included

- Detailed, layered wing feathers attached to the player's torso
- Sakura cloak attached to the shoulders, with subtle swing
- Petal crown attached to the head bone
- Amethyst horns that rotate with the head
- A dark plum/cherry-blossom cosmetics locker with Equip, Unequip, Equip all, Clear and Done
- A real 3D preview of your own player when the locker is opened **in a world**
- Cosmetic selections saved locally in `config/valtic-cosmetics-preview.properties`
- No particles, no external resource pack and no network or payment code

## Test

Install Fabric Loader and Fabric API for **Minecraft Java 26.3** (Java 25), and put the built `.jar` in `mods`.
Open **Cosmetics** on the Minecraft main menu or pause screen. Equip/unequip items independently.
For a live in-menu 3D player preview, use the pause menu while in a world; the title-screen locker has toggles but no player entity to render.
Use **F5** in the world to see the models.

The old commands also work: `/vcpreview all`, `/vcpreview off`, `/vcpreview wings`, `/vcpreview cape`, `/vcpreview hat`, `/vcpreview horns`.

All four cosmetics are deliberately unlocked **only in this preview build** so designs can be tested before purchase integration.
The test mod displays accessories on your own character; other players do not automatically see them.

## Build

Run `gradle build` with Gradle 9.8 and Java 25. Output: `build/libs/valtic-cosmetics-preview-0.2.0.jar`.

## Production plan

This standalone Fabric preview cannot run in Valtic's Rust Minecraft client without porting the 3D model rendering into that game renderer.
In production, a trusted backend must verify website purchases and cosmetics entitlements against signed-in Minecraft UUIDs; do not trust a local mod config for purchase checks.
The visual inspiration is the quality and locker workflow of Lunar Client, but the geometry, UI and textures here are original Valtic designs.
