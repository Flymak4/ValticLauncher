package dev.valtic.cosmetics;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.resources.Identifier;

/** Four baked 3D models rendered as player attachments. Textures are bundled inside the mod JAR. */
public final class CosmeticsLayer extends RenderLayer<AvatarRenderState, PlayerModel> {
    private static final String MOD = "valticcosmetics";
    public static final ModelLayerLocation CAPE_LAYER = layer("cape");
    public static final ModelLayerLocation WINGS_LAYER = layer("wings");
    public static final ModelLayerLocation HAT_LAYER = layer("hat");
    public static final ModelLayerLocation HORNS_LAYER = layer("horns");
    private static final Identifier CAPE_TEXTURE = tex("cape");
    private static final Identifier WINGS_TEXTURE = tex("wings");
    private static final Identifier HAT_TEXTURE = tex("hat");
    private static final Identifier HORNS_TEXTURE = tex("horns");

    private final ModelPart cape;
    private final ModelPart wings;
    private final ModelPart wingLeft;
    private final ModelPart wingRight;
    private final ModelPart hat;
    private final ModelPart horns;

    public CosmeticsLayer(RenderLayerParent<AvatarRenderState, PlayerModel> parent, EntityModelSet models) {
        super(parent);
        this.cape = models.bakeLayer(CAPE_LAYER).getChild("ornament");
        this.wings = models.bakeLayer(WINGS_LAYER).getChild("ornament");
        this.wingLeft = wings.getChild("left");
        this.wingRight = wings.getChild("right");
        this.hat = models.bakeLayer(HAT_LAYER).getChild("ornament");
        this.horns = models.bakeLayer(HORNS_LAYER).getChild("ornament");
    }

    private static ModelLayerLocation layer(String name) {
        return new ModelLayerLocation(Identifier.fromNamespaceAndPath(MOD, name), "main");
    }
    private static Identifier tex(String name) {
        return Identifier.fromNamespaceAndPath(MOD, "textures/cosmetic/" + name + ".png");
    }

    @Override
    public void submit(PoseStack pose, SubmitNodeCollector collector, int light, AvatarRenderState state,
                       float yRot, float xRot) {
        // Preview cosmetics are local-only. Other players should not have cosmetics forced on them.
        if (Minecraft.getInstance().player == null || state.id != Minecraft.getInstance().player.getId()
            || state.isSpectator || state.isInvisible) return;

        if (ValticCosmeticsClient.cape || ValticCosmeticsClient.wings) {
            pose.pushPose();
            getParentModel().body.translateAndRotate(pose);
            if (ValticCosmeticsClient.cape) {
                collector.submitModelPart(cape, pose, RenderTypes.entityCutout(CAPE_TEXTURE), light,
                    OverlayTexture.NO_OVERLAY, null, 0xFFFFFFFF);
            }
            if (ValticCosmeticsClient.wings) {
                // Gentle motion; no particles or gameplay effects.
                float flap = (float)Math.sin(System.nanoTime() * 0.0000000015) * 0.08f;
                wingLeft.yRot = 0.10f + flap;
                wingRight.yRot = -0.10f - flap;
                collector.submitModelPart(wings, pose, RenderTypes.entityCutout(WINGS_TEXTURE), light,
                    OverlayTexture.NO_OVERLAY, null, 0xFFFFFFFF);
            }
            pose.popPose();
        }
        if (ValticCosmeticsClient.hat || ValticCosmeticsClient.horns) {
            pose.pushPose();
            getParentModel().head.translateAndRotate(pose);
            if (ValticCosmeticsClient.hat) {
                collector.submitModelPart(hat, pose, RenderTypes.entityCutout(HAT_TEXTURE), light,
                    OverlayTexture.NO_OVERLAY, null, 0xFFFFFFFF);
            }
            if (ValticCosmeticsClient.horns) {
                collector.submitModelPart(horns, pose, RenderTypes.entityCutout(HORNS_TEXTURE), light,
                    OverlayTexture.NO_OVERLAY, null, 0xFFFFFFFF);
            }
            pose.popPose();
        }
    }

    private static PartDefinition part(MeshDefinition mesh) {
        return mesh.getRoot().addOrReplaceChild("ornament", CubeListBuilder.create(), PartPose.ZERO);
    }

    /** Two fabric panels with contrasting borders. Behind the torso (+Z). */
    public static LayerDefinition capeModel() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition p = part(mesh);
        p.addOrReplaceChild("cloth", CubeListBuilder.create().texOffs(0, 0)
            .addBox(-5.0f, -1.0f, 2.6f, 10.0f, 12.0f, 0.65f), PartPose.ZERO);
        p.addOrReplaceChild("hem", CubeListBuilder.create().texOffs(0, 26)
            .addBox(-5.3f, 10.0f, 2.7f, 10.6f, 1.2f, 0.8f), PartPose.ZERO);
        p.addOrReplaceChild("collar", CubeListBuilder.create().texOffs(0, 30)
            .addBox(-4.4f, -1.5f, 2.4f, 8.8f, 1.3f, 1.0f), PartPose.ZERO);
        return LayerDefinition.create(mesh, 64, 64);
    }

    /** Feather-like stylised cuboids forming each wing, attached to the back. */
    public static LayerDefinition wingsModel() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition p = part(mesh);
        PartDefinition left = p.addOrReplaceChild("left", CubeListBuilder.create(),
            PartPose.offset(2.5f, -1.0f, 2.4f));
        left.addOrReplaceChild("root", CubeListBuilder.create().texOffs(0, 0)
            .addBox(0f, 0f, 0f, 6f, 2.1f, 1.8f), PartPose.ZERO);
        left.addOrReplaceChild("upper", CubeListBuilder.create().texOffs(0, 8)
            .addBox(3.2f, -3f, 0.3f, 6f, 7f, 1.0f), PartPose.ZERO);
        left.addOrReplaceChild("tip", CubeListBuilder.create().texOffs(0, 26)
            .addBox(5.4f, 2.5f, 0.45f, 4f, 9f, 0.8f), PartPose.ZERO);
        PartDefinition right = p.addOrReplaceChild("right", CubeListBuilder.create(),
            PartPose.offset(-2.5f, -1.0f, 2.4f));
        right.addOrReplaceChild("root", CubeListBuilder.create().texOffs(0, 0)
            .addBox(-6f, 0f, 0f, 6f, 2.1f, 1.8f), PartPose.ZERO);
        right.addOrReplaceChild("upper", CubeListBuilder.create().texOffs(0, 8)
            .addBox(-9.2f, -3f, 0.3f, 6f, 7f, 1.0f), PartPose.ZERO);
        right.addOrReplaceChild("tip", CubeListBuilder.create().texOffs(0, 26)
            .addBox(-9.4f, 2.5f, 0.45f, 4f, 9f, 0.8f), PartPose.ZERO);
        return LayerDefinition.create(mesh, 64, 64);
    }

    /** Cherry-trimmed tall hat. Hat and horns can be toggled independently. */
    public static LayerDefinition hatModel() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition p = part(mesh);
        p.addOrReplaceChild("brim", CubeListBuilder.create().texOffs(0, 0)
            .addBox(-5.6f, -8.7f, -5.6f, 11.2f, 1.0f, 11.2f), PartPose.ZERO);
        p.addOrReplaceChild("crown", CubeListBuilder.create().texOffs(0, 26)
            .addBox(-4.15f, -13f, -4.15f, 8.3f, 4.4f, 8.3f), PartPose.ZERO);
        p.addOrReplaceChild("band", CubeListBuilder.create().texOffs(30, 28)
            .addBox(-4.3f, -10f, -4.3f, 8.6f, 1.0f, 8.6f), PartPose.ZERO);
        return LayerDefinition.create(mesh, 64, 64);
    }

    /** Pair of tapered amethyst-style horns with stepped tips. */
    public static LayerDefinition hornsModel() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition p = part(mesh);
        for (int side : new int[]{-1, 1}) {
            float x = side * 3.0f;
            p.addOrReplaceChild("horn_base_" + side, CubeListBuilder.create().texOffs(0, 0)
                .addBox(x - 1.2f, -10.0f, -1.0f, 2.4f, 3.0f, 2.4f), PartPose.ZERO);
            p.addOrReplaceChild("horn_middle_" + side, CubeListBuilder.create().texOffs(12, 0)
                .addBox(x - 0.8f + side * 0.5f, -12.7f, -0.8f, 1.6f, 3.0f, 1.8f), PartPose.ZERO);
            p.addOrReplaceChild("horn_tip_" + side, CubeListBuilder.create().texOffs(22, 0)
                .addBox(x - 0.45f + side * 1.0f, -14.7f, -0.5f, 0.9f, 2.2f, 1.0f), PartPose.ZERO);
        }
        return LayerDefinition.create(mesh, 64, 64);
    }
}
