package dev.valtic.cosmetics;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityRenderLayerRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.network.chat.Component;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Client-side preview: free testing only. Purchases must later be checked by a server API. */
public final class ValticCosmeticsClient implements ClientModInitializer {
    public static volatile boolean cape = false;
    public static volatile boolean wings = false;
    public static volatile boolean hat = false;
    public static volatile boolean horns = false;
    private static final Path CONFIG = FabricLoader.getInstance().getConfigDir().resolve("valtic-cosmetics-preview.properties");

    public static boolean enabled(int category) {
        return switch (category) {
            case 0 -> wings;
            case 1 -> cape;
            case 2 -> hat;
            case 3 -> horns;
            default -> false;
        };
    }
    public static void toggle(int category) { set(category, !enabled(category)); }
    public static void set(int category, boolean value) {
        switch (category) {
            case 0 -> wings = value;
            case 1 -> cape = value;
            case 2 -> hat = value;
            case 3 -> horns = value;
            default -> { return; }
        }
        saveSelections();
    }
    public static void setAll(boolean value) {
        wings = cape = hat = horns = value;
        saveSelections();
    }
    private static void loadSelections() {
        Properties settings = new Properties();
        if (!Files.isRegularFile(CONFIG)) return;
        try (InputStream stream = Files.newInputStream(CONFIG)) {
            settings.load(stream);
            cape = Boolean.parseBoolean(settings.getProperty("cape", "false"));
            wings = Boolean.parseBoolean(settings.getProperty("wings", "false"));
            hat = Boolean.parseBoolean(settings.getProperty("hat", "false"));
            horns = Boolean.parseBoolean(settings.getProperty("horns", "false"));
        } catch (Exception e) {
            System.err.println("[Valtic] Could not load preview selections: " + e.getMessage());
        }
    }
    public static void saveSelections() {
        Properties settings = new Properties();
        settings.setProperty("cape", Boolean.toString(cape));
        settings.setProperty("wings", Boolean.toString(wings));
        settings.setProperty("hat", Boolean.toString(hat));
        settings.setProperty("horns", Boolean.toString(horns));
        try {
            Files.createDirectories(CONFIG.getParent());
            try (OutputStream stream = Files.newOutputStream(CONFIG)) {
                settings.store(stream, "Valtic client-only cosmetic preview settings");
            }
        } catch (Exception e) {
            System.err.println("[Valtic] Could not save preview selections: " + e.getMessage());
        }
    }

    @Override
    public void onInitializeClient() {
        loadSelections();
        ModelLayerRegistry.registerModelLayer(CosmeticsLayer.CAPE_LAYER, CosmeticsLayer::capeModel);
        ModelLayerRegistry.registerModelLayer(CosmeticsLayer.WINGS_LAYER, CosmeticsLayer::wingsModel);
        ModelLayerRegistry.registerModelLayer(CosmeticsLayer.HAT_LAYER, CosmeticsLayer::hatModel);
        ModelLayerRegistry.registerModelLayer(CosmeticsLayer.HORNS_LAYER, CosmeticsLayer::hornsModel);

        LivingEntityRenderLayerRegistrationCallback.EVENT.register((entityType, renderer, helper, context) -> {
            if (renderer instanceof AvatarRenderer<?> avatar) {
                helper.register(new CosmeticsLayer(avatar, context.getModelSet()));
            }
        });

        // A real, working Locker on the Minecraft title and pause menus.
        ScreenEvents.AFTER_INIT.register((minecraft, screen, width, height) -> {
            if (screen instanceof TitleScreen || screen instanceof PauseScreen) {
                int y = screen instanceof TitleScreen ? Math.min(height - 44, height / 4 + 158) : height - 44;
                Screens.getWidgets(screen).add(Button.builder(
                    Component.literal("Valtic Cosmetics"),
                    button -> minecraft.gui.setScreen(new CosmeticsScreen(screen))
                ).bounds(width / 2 - 100, Math.max(8, y), 200, 20).build());
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, access) -> dispatcher.register(
            ClientCommands.literal("vcpreview")
                .executes(ctx -> feedback(ctx.getSource(), "Open Cosmetics on the main menu or pause screen."))
                .then(ClientCommands.literal("all").executes(ctx -> {
                    setAll(true);
                    return feedback(ctx.getSource(), "All four cosmetics equipped.");
                }))
                .then(ClientCommands.literal("off").executes(ctx -> {
                    setAll(false);
                    return feedback(ctx.getSource(), "All cosmetics unequipped.");
                }))
                .then(ClientCommands.literal("cape").executes(ctx -> select(ctx.getSource(), "cape")))
                .then(ClientCommands.literal("wings").executes(ctx -> select(ctx.getSource(), "wings")))
                .then(ClientCommands.literal("hat").executes(ctx -> select(ctx.getSource(), "hat")))
                .then(ClientCommands.literal("horns").executes(ctx -> select(ctx.getSource(), "horns")))
        ));
    }

    private static int select(net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource source, String kind) {
        setAll(false);
        set(switch (kind) { case "wings" -> 0; case "cape" -> 1; case "hat" -> 2; default -> 3; }, true);
        return feedback(source, "Equipped " + kind + ". Open Cosmetics to try combinations.");
    }
    private static int feedback(net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource source, String message) {
        source.sendFeedback(Component.literal("[Valtic] " + message));
        return 1;
    }
}
