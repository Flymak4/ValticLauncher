package dev.valtic.cosmetics;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityRenderLayerRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.network.chat.Component;

/** Preview only: no store, paid unlock checks, accounts, HTTP calls, or server installs. */
public final class ValticCosmeticsClient implements ClientModInitializer {
    public static volatile boolean cape = true;
    public static volatile boolean wings = true;
    public static volatile boolean hat = true;
    public static volatile boolean horns = true;

    @Override
    public void onInitializeClient() {
        ModelLayerRegistry.registerModelLayer(CosmeticsLayer.CAPE_LAYER, CosmeticsLayer::capeModel);
        ModelLayerRegistry.registerModelLayer(CosmeticsLayer.WINGS_LAYER, CosmeticsLayer::wingsModel);
        ModelLayerRegistry.registerModelLayer(CosmeticsLayer.HAT_LAYER, CosmeticsLayer::hatModel);
        ModelLayerRegistry.registerModelLayer(CosmeticsLayer.HORNS_LAYER, CosmeticsLayer::hornsModel);

        LivingEntityRenderLayerRegistrationCallback.EVENT.register((entityType, renderer, helper, context) -> {
            if (renderer instanceof AvatarRenderer<?> avatar) {
                helper.register(new CosmeticsLayer(avatar, context.getModelSet()));
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, access) -> dispatcher.register(
            ClientCommands.literal("vcpreview")
                .executes(ctx -> feedback(ctx.getSource(), "Usage: /vcpreview all | off | cape | wings | hat | horns"))
                .then(ClientCommands.literal("all").executes(ctx -> {
                    cape = wings = hat = horns = true;
                    return feedback(ctx.getSource(), "Showing all four Valtic cosmetics. Press F5 for third-person view.");
                }))
                .then(ClientCommands.literal("off").executes(ctx -> {
                    cape = wings = hat = horns = false;
                    return feedback(ctx.getSource(), "All Valtic cosmetics hidden.");
                }))
                .then(ClientCommands.literal("cape").executes(ctx -> select(ctx.getSource(), "cape")))
                .then(ClientCommands.literal("wings").executes(ctx -> select(ctx.getSource(), "wings")))
                .then(ClientCommands.literal("hat").executes(ctx -> select(ctx.getSource(), "hat")))
                .then(ClientCommands.literal("horns").executes(ctx -> select(ctx.getSource(), "horns")))
        ));
    }

    private static int select(net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource source, String kind) {
        cape = kind.equals("cape");
        wings = kind.equals("wings");
        hat = kind.equals("hat");
        horns = kind.equals("horns");
        return feedback(source, "Previewing " + kind + ". Use F5 to look at the cosmetic.");
    }

    private static int feedback(net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource source, String message) {
        source.sendFeedback(Component.literal("[Valtic] " + message));
        return 1;
    }
}
