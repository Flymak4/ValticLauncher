package dev.valtic.cosmetics;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;

/** Original, cherry-plum Valtic cosmetic locker with real equip/unequip controls.
 *  The 26.3 player preview renders the game's actual player, not an image overlay.
 */
public final class CosmeticsScreen extends Screen {
    private static final String[] NAMES = {"Wings", "Capes", "Hats", "Horns"};
    private static final String[] DESCRIPTIONS = {
        "Rosewing  |  layered 3D feathers", "Sakura cloak  |  shoulder-mounted",
        "Petal crown  |  head attachment", "Amethyst horns  |  head attachment"
    };
    private static final int BG = 0xF3111020;
    private static final int PANEL = 0xF51C1429;
    private static final int SECTION = 0xA52C2139;
    private static final int BORDER = 0xFF75516F;
    private static final int WHITE = 0xFFF4E9F5;
    private static final int MUTED = 0xFFD1B8CB;
    private static final int PINK = 0xFFFF9BCE;
    private final Screen previous;

    public CosmeticsScreen(Screen previous) {
        super(Component.literal("Valtic Cosmetics"));
        this.previous = previous;
    }

    private int left() { return (width - Math.min(width - 22, 638)) / 2; }
    private int top() { return (height - Math.min(height - 12, 316)) / 2; }
    private int panelWidth() { return Math.min(width - 22, 638); }
    private int panelHeight() { return Math.min(height - 12, 316); }
    private boolean showPreview() { return panelWidth() >= 460 && minecraft != null && minecraft.player != null; }
    private int listX() { return left() + (showPreview() ? 232 : 16); }
    private int listWidth() { return panelWidth() - (listX() - left()) - 16; }

    @Override
    protected void init() {
        int x = listX();
        int right = left() + panelWidth() - 16;
        int rowY = top() + 62;
        for (int i = 0; i < NAMES.length; i++) {
            final int slot = i;
            addRenderableWidget(Button.builder(
                Component.literal(ValticCosmeticsClient.enabled(slot) ? "Unequip" : "Equip"),
                button -> {
                    ValticCosmeticsClient.toggle(slot);
                    button.setMessage(Component.literal(ValticCosmeticsClient.enabled(slot) ? "Unequip" : "Equip"));
                }
            ).bounds(right - 89, rowY + i * 42 + 7, 89, 20).build());
        }
        int actionsY = Math.min(top() + 251, top() + panelHeight() - 27);
        addRenderableWidget(Button.builder(Component.literal("Equip all"), b -> {
            ValticCosmeticsClient.setAll(true);
            rebuildWidgets();
        }).bounds(x, actionsY, Math.min(90, listWidth() / 3), 20).build());
        addRenderableWidget(Button.builder(Component.literal("Clear"), b -> {
            ValticCosmeticsClient.setAll(false);
            rebuildWidgets();
        }).bounds(x + Math.min(90, listWidth() / 3) + 5, actionsY, Math.min(80, listWidth() / 3), 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
            .bounds(right - 80, actionsY, 80, 20).build());
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(0, 0, width, height, BG);
        int x = left(), y = top(), w = panelWidth(), h = panelHeight();
        graphics.fill(x, y, x + w, y + h, PANEL);
        graphics.outline(x, y, w, h, BORDER);
        graphics.fill(x + 1, y + 1, x + w - 1, y + 4, 0xFFB85D8B);
        graphics.fill(x + 14, y + 47, x + w - 14, y + 48, BORDER);
        if (showPreview()) {
            graphics.fill(x + 14, y + 55, x + 221, y + h - 39, SECTION);
            graphics.outline(x + 14, y + 55, 207, h - 94, BORDER);
        }
        int startX = listX(), lw = listWidth();
        for (int i = 0; i < NAMES.length; i++) {
            int row = y + 62 + i * 42;
            graphics.fill(startX, row, startX + lw, row + 36, SECTION);
            graphics.outline(startX, row, lw, 36, ValticCosmeticsClient.enabled(i) ? PINK : BORDER);
            if (ValticCosmeticsClient.enabled(i)) graphics.fill(startX, row, startX + 3, row + 36, PINK);
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
        int x = left(), y = top();
        graphics.text(font, "VALTIC   /   COSMETICS", x + 17, y + 12, WHITE);
        graphics.text(font, "Preview locker  -  all items unlocked for testing", x + 17, y + 28, MUTED);
        int startX = listX();
        for (int i = 0; i < NAMES.length; i++) {
            int row = y + 62 + i * 42;
            graphics.text(font, NAMES[i], startX + 10, row + 5, WHITE);
            graphics.text(font, DESCRIPTIONS[i], startX + 10, row + 20, MUTED);
        }
        if (showPreview()) {
            int previewX = x + 24;
            graphics.text(font, "LIVE PLAYER PREVIEW", previewX + 4, y + 62, PINK);
            // The 3D preview renders the equipped layers on the actual Minecraft player.
            InventoryScreen.extractEntityInInventoryFollowsMouse(
                graphics, previewX + 5, y + 79, previewX + 180, y + 223,
                62, 0, mouseX, mouseY, minecraft.player
            );
            graphics.text(font, "Move mouse to rotate", previewX + 22, y + 231, MUTED);
        } else {
            graphics.text(font, "Equip items here, then press F5 in a world to view them.",
                x + 18, y + panelHeight() - 51, MUTED);
        }
        graphics.text(font, "Preview only - no store or paid unlocks are active.",
            x + 16, y + panelHeight() - 13, MUTED);
    }

    @Override
    public void onClose() {
        ValticCosmeticsClient.saveSelections();
        minecraft.gui.setScreen(previous);
    }
}
